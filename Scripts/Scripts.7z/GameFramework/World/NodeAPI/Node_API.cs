/********************************************************************
生成日期:	1:11:2020 13:16
类    名: 	WorldNode
作    者:	HappLI
描    述:	世界节点
*********************************************************************/
#if USE_FIXEDMATH
using ExternEngine;
#else
using FFloat = System.Single;
using FVector3 = UnityEngine.Vector3;
#endif
using System.Collections.Generic;
using UnityEngine;

namespace Framework.Core
{
    public abstract partial class AWorldNode
    {
        protected virtual void InnerCreated() { }
        protected virtual void OnContextDataDirty() { }
        //------------------------------------------------------
        protected abstract void OnDestroy();
        protected virtual void OnReleaseGC() { }
        //-------------------------------------------------
        public virtual FFloat GetTurnTime()
        {
#if USE_FIXEDMATH
            return new FFloat(0.1f);
#else
            return 0.1f;
#endif
        }
        //-------------------------------------------------
        internal virtual void SetRVOVelocity(FVector3 speed)
        {

        }
        //-------------------------------------------------
        internal virtual FVector3 GetRVOVelocity()
        {
            return FVector3.zero;
        }
        //-------------------------------------------------
        public virtual void SetSpeed(FVector3 speed)
        {

        }
        //-------------------------------------------------
        public virtual void SetSpeedXZ(FVector3 vSpeed)
        {

        }
        //-------------------------------------------------
        public virtual FVector3 GetSpeed()
        {
            return FVector3.zero;
        }
        //------------------------------------------------------
        public virtual FFloat GetRunSpeed()
        {
            return 5;
        }
        //------------------------------------------------------
        public virtual FFloat GetFastRunSpeed()
        {
            return 10;
        }
        //------------------------------------------------------
        public virtual FFloat GetPhysicRadius()
        {
            return m_Transform.GetScaleMag()*0.5f;
        }
        //------------------------------------------------------
        public virtual FFloat GetTimeSpeed()
        {
#if USE_FIXEDMATH
            if (IsFreezed()) return FFloat.zero;
            return FFloat.one;
#else
            if (IsFreezed()) return 0.0f;
            return 1.0f;
#endif
        }
        //------------------------------------------------------
        public virtual bool IsRunAlongPath()
        {
            return false;
        }
        //------------------------------------------------------
        public virtual bool IsLocalRunAlongPath()
        {
            return false;
        }
        //------------------------------------------------------
        public virtual void AppendRunAlongPathByTimeStep(FVector3 point, FFloat fTime, int nInsertIndex = -1)
        {

        }
        //------------------------------------------------------
        public virtual FFloat RunAlongPathPoint(List<FVector3> vPoints, FFloat fSpeed, bool bEnsureSucceed = false, bool bUpdateDirection = true, bool bLocalRun = false)
        {
            return 0;
        }
        //------------------------------------------------------
        public virtual FFloat RunAlongPathPoint(FVector3 srcPos, FVector3 toPos, FFloat fSpeed, bool bEnsureSucceed = false, bool bUpdateDirection = true, bool bLocalRun = false)
        {
            return 0;
        }
        //------------------------------------------------------
        public virtual FFloat RunAlongPathPoint(FVector3 toPos, FFloat fSpeed, bool bEnsureSucceed = false, bool bUpdateDirection = true, bool bLocalRun = false)
        {
            return 0;
        }
        //------------------------------------------------------
        public virtual void StopRunAlongPathPoint()
        {

        }
        //------------------------------------------------------
        public virtual void PauseRunAlongPathPoint()
        {

        }
        //------------------------------------------------------
        public virtual void ResumeRunAlongPathPoint()
        {

        }
        //------------------------------------------------------
        public virtual bool IsRunAlongPathPlaying()
        {
            return IsRunAlongPath();
        }
        //------------------------------------------------------
        public virtual bool OnWorldTrigger(AWorldNode pTrigger, WorldTriggerParamter parameter)
        {
            return true;
        }
#if USE_AISYSTEM
        //------------------------------------------------------
        public virtual AI.AIAgent GetAI()
        {
            return null;
        }
#endif
        //-------------------------------------------------
        protected virtual void InnerUpdate(FFloat fFrame) { }
        //-------------------------------------------------
        protected virtual void OnInnerSpawnObject(IUserData userData) { }
        //------------------------------------------------------
        public AFramework GetGameModule()
        {
            return m_pGame;
        }
        //------------------------------------------------------
        public virtual IUserData GetStateParam()
        {
            return null;
        }
        //------------------------------------------------------
        protected virtual void OnFreezed(bool freeze) 
        {
            if (m_pServerSync != null) m_pServerSync.OutSyncData(new SvrSyncData((int)EDefaultSyncType.Freeze, freeze ));
        }
        //------------------------------------------------------
        public virtual void OnLogicCall(IUserData takeData)
        {

        }
        //------------------------------------------------------
        public abstract uint GetConfigID();
        //------------------------------------------------------
        public virtual bool RayHit(Ray ray)
        {
            if (ray.GetPoint((ray.origin - GetPosition()).magnitude).y < GetPosition().y)
                return false;
            m_BoundBox.SetTransform(GetMatrix());
            return GetBounds().RayHit(ray);
        }
        //------------------------------------------------------
#if UNITY_EDITOR
        //------------------------------------------------------
        public virtual void DrawDebug()
        {
            UnityEditor.Handles.Label(GetPosition(), GetActorType().ToString() + ":" + GetInstanceID().ToString() + " config:" + GetConfigID());
            ED.EditorHepler.DrawBoundingBox(m_BoundBox.GetCenter(), m_BoundBox.GetHalf(), GetMatrix(), Color.green, true);
        }
#endif
    }
}
