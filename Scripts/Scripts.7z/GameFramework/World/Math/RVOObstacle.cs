﻿// using UnityEngine;
// 
// namespace RVO
// {
//     struct RVOObstacle
//     {
//         public bool IsConvex;
//         public Vector3 point;
//         public Vector3 unitDir;
//         public int id;
//         public int userId;
//     }
// }