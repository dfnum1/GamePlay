/********************************************************************
生成日期:	1:11:2020 13:16
类    名: 	WordBoundSphere
作    者:	HappLI
描    述:	WordBoundSphere
*********************************************************************/
using UnityEngine;

namespace Framework.Core
{
    public struct WordBoundSphere
    {
    }
}
