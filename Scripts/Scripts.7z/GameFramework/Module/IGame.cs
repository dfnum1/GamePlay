﻿/********************************************************************
生成日期:	3:10:2019  15:03
类    名: 	IGame
作    者:	HappLI
描    述:	游戏对象基础主接口
*********************************************************************/
using System;
using System.Collections;
using Framework.Core;
using UnityEngine;

namespace Framework.Module
{
    public interface IGame
    {
        Coroutine BeginCoroutine(IEnumerator coroutine);
        void EndAllCoroutine();
        void EndCoroutine(Coroutine cortuine);
        void EndCoroutine(IEnumerator cortuine);
        //  EFileSystemType GetFileStreamType();
        int GetMaxThread();
        bool IsEditor();

        //  UISystem GetUISystem();
        //  AudioManager GetAudioMgr();
        ScriptableObject[] GetDatas();
        Transform GetTransform();
        //   CameraSetting GetCameraSetting();

        UnityEngine.Rendering.RenderPipelineAsset GetURPAsset();
    }

}
