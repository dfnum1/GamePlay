/********************************************************************
生成日期:	17:9:2019   16:19
类    名: 	TimerUtil
作    者:	HappLI
描    述:	时间工具集
*********************************************************************/
using System;
using UnityEngine;

namespace Framework.Base
{
    public static class TimerUtil
    {
        private static readonly long epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).Ticks;
        //-----------------------------------------------------
        /// <summary>
        /// 客户端时间
        /// </summary>
        /// <returns></returns>
        public static long ClientNow()
        {
            return (DateTime.UtcNow.Ticks - epoch) / 10000;
        }
        //-----------------------------------------------------
        public static long ClientNowSeconds()
        {
            return (DateTime.UtcNow.Ticks - epoch) / 10000000;
        }
        //-----------------------------------------------------
        public static long Now()
        {
            return ClientNow();
        }
        //-----------------------------------------------------
        /// <summary>
        /// 将时间转换成00:00:00的格式,秒为单位
        /// 例如 90 对应 00:01:30
        /// </summary>
        /// <param name="time">单位秒</param>
        /// <returns></returns>
        public static string GetTimeForString(long time, bool isHourZeroHide = false)
        {
            long hour = time / 3600;
            long minute = (time % 3600) / 60;
            long second = time % 60;
            if (isHourZeroHide && hour == 0)
            {
                return BaseUtil.stringBuilder.Append(minute.ToString("00")).Append(":").Append(second.ToString("00")).ToString();
            }
            return BaseUtil.stringBuilder.Append(hour.ToString("00")).Append(":").Append(minute.ToString("00")).Append(":").Append(second.ToString("00")).ToString();
        }
        /*
        //-----------------------------------------------------
        /// <summary>
        /// 大于1天时,将时间转换成x天x小时,秒为单位,
        /// </summary>
        /// <param name="time">单位秒</param>
        /// <returns></returns>
        public static string GetTimeForStringDayFormat(long time)
        {
            if (time >= 86400)
            {
                long day = time / 86400;
                long dayLeft = time % 86400;
                long hour = dayLeft / 3600;

                return BaseUtil.stringBuilder.Append(day.ToString()).Append(LocalizationUtil.Convert(80022272)).Append(" ").Append(hour.ToString()).Append(LocalizationUtil.Convert(80022273)).ToString();
            }
            else
            {
                return GetTimeForString(time);
            }
        }
        //-----------------------------------------------------
        /// <summary>
        /// 将时间转换成x天x小时,秒为单位
        /// </summary>
        /// <param name="time">单位秒</param>
        /// <returns></returns>
        public static string GetTimeForStringHourFormat(long time)
        {
            long day = time / 86400;
            long dayLeft = time % 86400;
            long hour = dayLeft / 3600;

            return BaseUtil.stringBuilder.Append(day.ToString()).Append(LocalizationUtil.Convert(80020126)).Append(hour.ToString()).Append(LocalizationUtil.Convert(80020127)).ToString(); ;
        }
        //-----------------------------------------------------
        /// <summary>
        /// 大于24小时，显示X天
        /// 大于1小时，小于24小时，显示X小时
        /// 小于1小时，显示倒计时，例如59:59
        /// </summary>
        /// <param name="time">单位秒</param>
        /// <returns></returns>
        public static string GetTimeFormatForString(long time)
        {
            if (time > 86400)
            {
                return BaseUtil.stringBuilder.Append(Mathf.CeilToInt(time / 86400)).Append(LocalizationUtil.Convert(80020126)).ToString();
            }
            else if (time > 3600)
            {
                return BaseUtil.stringBuilder.Append(Mathf.CeilToInt(time / 3600)).Append(LocalizationUtil.Convert(80020127)).ToString();
            }

            return new TimeSpan(time * 10000000).ToString("mm\\:ss");
        }
        //------------------------------------------------------
        /// <summary>
        /// 建造时间显示转换成时间：
        /// 小于60秒显示：XX秒
        /// 60秒 ~60分钟：XX分XX秒
        /// 大于60分钟：X小时X分
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string GetBuildingTimeString(long time)
        {
            
            if (time > 3600)
            {
                return BaseUtil.stringBuilder.Append(Mathf.CeilToInt(time / 3600)).Append(LocalizationUtil.Convert(80020127)).Append(Mathf.CeilToInt(time % 3600 /60)).Append(LocalizationUtil.Convert(80022250)).ToString();
            }
            else if(time > 60)
            {
                return BaseUtil.stringBuilder.Append(Mathf.CeilToInt(time / 60)).Append(LocalizationUtil.Convert(80022250)).Append(Mathf.CeilToInt(time % 60)).Append(LocalizationUtil.Convert(80010225)).ToString();
            }
            

            return BaseUtil.stringBuilder.Append(Mathf.CeilToInt(time)).Append(LocalizationUtil.Convert(80010225)).ToString();
        }
        //-----------------------------------------------------
        /// <summary>
        /// 超过一天显示X天00:00:00
        /// 小于一天显示 00:00:00
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string GetTimeFormatForString2(long time)
        {
            if (time >= 86400)
            {
                long day = time / 86400;
                long dayLeft = time % 86400;

                long hour = dayLeft / 3600;
                long minute = (dayLeft % 3600) / 60;
                long second = ((dayLeft % 3600) % 60) % 60;

                return BaseUtil.stringBuilder.Append(day.ToString()).Append(LocalizationUtil.Convert(80020126)).Append(hour.ToString("00")).Append(":").Append(minute.ToString("00")).Append(":").Append(second.ToString("00")).ToString();
            }
            else
            {
                return GetTimeForString(time);
            }
        }*/
        //------------------------------------------------------
        /// <summary>
        /// 获取本地当前时间戳,单位毫秒
        /// </summary>
        /// <returns></returns>
        public static long GetClientTimeStamp()
        {
            return (DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000;
        }
        //------------------------------------------------------
        public static string GetTimeStringFromTimeStamp(long timeStamp, string format = "yyyy-MM-dd HH:mm:ss:ffff")
        {
            System.DateTime startTime = new System.DateTime(1970, 1, 1, 8, 0, 0);
            return startTime.AddSeconds(timeStamp).ToString(format);
        }
    }
}