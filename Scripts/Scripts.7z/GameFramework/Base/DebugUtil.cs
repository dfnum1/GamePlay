/********************************************************************
生成日期:	1:11:2020 10:06
类    名: 	DebugUtil
作    者:	HappLI
描    述:	框架调试配置
*********************************************************************/
using System.Collections.Generic;
using UnityEngine;
namespace Framework.Base
{
    public class DebugUtil
    {
        public static string ImprisonLinkEffect = null;
        public static string LinkEffect = null;
        public static string PartAimPoint = null;

        public static int globalTeamSoulFlagDefer = 1000; 

        public static bool bDamageDebug = false;
        public static bool bSkillDebug = false;
        public static bool bBattleFameWriteLogFile = false;

        public static bool bShowSpatial = false;
        public static bool bShowNodeDebugFrame = false;
        public static bool bEventTriggerDebug = false;

        public static bool bEnableGuide = true;
        public static bool bEnableGuideSkip = false;
        public static bool bGuideLogEnable = false;

        private static bool ms_bSupportInstance = true;
        private static bool m_bProfilerDebug = false;
        public static bool bProfilerDebug
        {
            get
            {
#if UNITY_EDITOR || USE_SERVER
                return m_bProfilerDebug;
#else
                return false;
#endif
            }
            set
            {
                m_bProfilerDebug = value;
            }
        }

        //------------------------------------------------------
        public static void Init()
        {
        }
        //------------------------------------------------------
        public static void EnableSupportInstancing(bool bEnable)
        {
            ms_bSupportInstance = bEnable;
#if !USE_SERVER
            if (!ms_bSupportInstance)
                Shader.DisableKeyword("UNITY_SUPPORT_INSTANCING");
#endif
        }
        //------------------------------------------------------
        public static bool IsSupportInstancing
        {
            get { return ms_bSupportInstance; }
            set
            {
                EnableSupportInstancing(value);
            }
        }
        //------------------------------------------------------
        public static long ConverVersion(string version)
        {
            long result = 0;
            long.TryParse(version.Replace(".", ""), out result);
            return result;
        }
    }
}
